# Relatório parcial M2 — ALPR didático

## 1. Problema e objetivos atuais

O projeto investiga o reconhecimento automático de placas veiculares (ALPR): localizar a placa em uma imagem, alinhar sua perspectiva, separar caracteres e reconhecer o texto. A implementação atual é parcial. O fluxo executável começa com um recorte de placa e produz máscaras binárias e estatísticas de componentes. Ainda não localiza placas em fotografias de veículos completos, não retifica perspectiva e não executa OCR.

## 2. Evolução desde a M1 e revisão da proposta

A proposta da M1 previa pré-processamento, comparação entre contornos e Haar Cascade, retificação, segmentação e OCR. O ZIP recebido contém `samples-cropped.png`, uma montagem com 20 recortes, mas não contém o dataset completo de cenas veiculares, anotações ou código anterior. Por isso, o escopo implementado na M2 foi ajustado para investigar a segmentação inicial nos recortes disponíveis.

| Item planejado na M1 | Situação na M2 | Evidência / justificativa |
|---|---|---|
| Pré-processamento | Implementado parcialmente | `src/pipeline.py`: escala de cinza, CLAHE e filtro Gaussiano; saídas por amostra |
| Detecção da placa em cena completa | Pendente | A entrada disponível já contém recortes de placa; não é adequada para medir localização em veículos completos |
| Comparação entre métodos de detecção | Pendente | Exige cenas completas e referência de bounding boxes |
| Correção de perspectiva | Pendente | Exige cantos da placa ou método confiável para estimá-los |
| Segmentação de caracteres | Exploração inicial | Máscaras, abertura morfológica e componentes conexos; sem referência de caracteres |
| OCR | Pendente | Será integrado depois de obter recortes e segmentações adequadas |

Não foi fornecido feedback formal do docente junto ao material recebido. Portanto, não se afirma que recomendações específicas foram atendidas; o grupo deve acrescentar aqui o feedback real e a resposta correspondente.

## 3. Dados e protocolo experimental

### Dados disponíveis

- Arquivo: `imagens/input/samples-cropped.png`.
- Dimensões: 1757 × 487 pixels.
- Conteúdo: montagem regular de 20 recortes de placas, divididos operacionalmente em 5 colunas × 4 linhas.
- Variações visíveis: contraste, iluminação, desfoque, inclinação e aparência dos caracteres.
- Anotações: não há ground truth de máscaras, caixas de caracteres ou transcrições por recorte no repositório recebido.

A quantidade de 20 recortes é suficiente para uma exploração inicial do comportamento dos parâmetros, mas não para sustentar alegações de desempenho geral. A divisão em grade é baseada na composição visual da montagem e pode cortar pixels nas bordas; para experimentos finais, cada imagem deve ser armazenada como arquivo individual e identificada por ID.

O dataset RodoSol-ALPR é descrito na proposta, mas não está presente no material recebido. A obtenção e o uso devem respeitar o procedimento e as condições de licença do repositório oficial.

### Protocolo

O mesmo conjunto de 20 recortes e o mesmo pré-processamento foram usados nas duas configurações. A variável alterada é a escolha do limiar:

- **A — fixo:** limiar 120, configurado por `--threshold 120`.
- **B — Otsu:** limiar global escolhido automaticamente pelo histograma de cada imagem.

Parâmetros mantidos: CLAHE (`clipLimit=2.0`, grade 8 × 8), filtro Gaussiano 3 × 3, limiarização inversa, abertura morfológica com elemento retangular 3 × 3 e uma iteração, conectividade 8 e área mínima de componente de 12 pixels. A área mínima filtra componentes nas estatísticas/visualizações, não altera a máscara binária.

## 4. Pipeline implementado

1. **Entrada:** arquivo de imagem. Opcionalmente, a montagem é dividida em 20 recortes pela opção `--split-grid 5 4`.
2. **Escala de cinza:** reduz a imagem a intensidade para facilitar a análise do histograma.
3. **CLAHE:** equalização adaptativa limitada de contraste para melhorar variações locais. Pode amplificar ruído.
4. **Filtro Gaussiano 3 × 3:** reduz ruído de alta frequência, mas pode suavizar traços finos.
5. **Limiarização inversa:** pixels abaixo do limiar ficam brancos (255) na máscara e pixels acima ficam pretos (0), buscando deixar traços escuros como primeiro plano.
6. **Abertura morfológica:** erosão seguida de dilatação, usando kernel retangular 3 × 3, para remover pequenos pontos. Pode apagar partes finas de caracteres.
7. **Componentes conexos:** rotula regiões brancas conectadas com conectividade 8 e calcula estatísticas. Componentes menores que 12 pixels não entram na contagem filtrada.
8. **Saídas:** imagens intermediárias por recorte e CSV com limiar, pixels de primeiro plano, razão de primeiro plano e contagem de componentes filtrados.

### Comando reproduzível

```bash
python -m pip install -r requirements.txt
python src/pipeline.py --input imagens/input/samples-cropped.png --output results --split-grid 5 4
```

A execução gera `results/comparison.csv` e subdiretórios `sample_*/` com imagens de saída. Para uma imagem individual, omita `--split-grid`.

## 5. Experimento: limiar fixo versus Otsu

### Pergunta

A seleção automática do limiar de Otsu produz máscaras substancialmente diferentes do limiar fixo 120 nos recortes de placas?

### Configuração e indicador

Foi mantido todo o pipeline igual, alterando apenas o método/valor do limiar. Foram registrados dois indicadores diagnósticos:

- **Razão de primeiro plano (%):** número de pixels brancos na máscara morfológica dividido pelo total de pixels da imagem, multiplicado por 100.
- **Componentes filtrados:** número de componentes conexos com área ≥ 12 pixels.

Esses indicadores descrevem as saídas e ajudam a identificar configurações que produzem máscaras muito densas ou fragmentadas. **Não medem diretamente a qualidade da segmentação dos caracteres**, pois ainda não há máscaras de referência nem contagem correta validada. Assim, a comparação é preliminar e não permite concluir que um método é mais preciso.

### Resultados agregados observados

A execução de referência sobre os 20 recortes produziu os seguintes valores agregados:

| Indicador | Limiar fixo 120 | Otsu |
|---|---:|---:|
| Razão média de primeiro plano | 50,10% | 59,46% |
| Mediana da razão de primeiro plano | 54,20% | 60,06% |
| Mínimo da razão de primeiro plano | 15,24% | 35,61% |
| Mediana de componentes com área ≥ 12 px | 10,5 | 9 |
| Mínimo de componentes filtrados | 3 | 3 |
| Máximo de componentes filtrados | 30 | 22 |

Os resultados completos por recorte estão em `results/comparison.csv` e devem ser regenerados com o comando descrito acima.

### Interpretação

Otsu gerou, em média, uma proporção maior de pixels de primeiro plano. Isso mostra que, nesta montagem, a escolha automática do limiar altera materialmente a máscara; não prova que os caracteres foram segmentados melhor. A mediana de componentes foi ligeiramente menor com Otsu, enquanto o máximo também foi menor, o que sugere diferenças na fragmentação/densidade, mas a contagem pode incluir moldura, parafusos, ruído e caracteres conectados.

### Casos de sucesso e limitações observadas

- **Comportamento útil:** em recortes com fundo relativamente uniforme e caracteres escuros, as máscaras deixam traços dos caracteres visíveis para análise posterior. Isso é apenas uma inspeção visual qualitativa; não foi medido contra uma referência.
- **Falha/limitação:** recortes com reflexo, baixa iluminação, desfoque ou baixo contraste podem produzir máscara excessivamente preenchida, traços quebrados ou componentes misturados. Otsu também é um limiar global e não resolve necessariamente iluminação desigual dentro da mesma placa.
- **Limitação da entrada:** a divisão da montagem em grade não equivale a uma base organizada de imagens independentes e pode incluir bordas de separação. O experimento deve ser repetido com os 20 recortes salvos separadamente.

## 6. Referência de avaliação e métricas futuras

Não há referência manual no repositório para calcular IoU/Dice de máscaras, erro de contagem de caracteres ou taxa de detecção. Os indicadores atuais são descritivos, e essa limitação deve ser mantida explícita no vídeo e na apresentação.

Para M3, criar uma tabela por imagem com ID, texto esperado, bounding box da placa e, para um subconjunto, máscaras ou caixas dos caracteres. A anotação deve ser revisada por pelo menos um segundo integrante; registrar ambiguidades (placa ilegível, oclusão, reflexo). Avaliar a detecção por IoU entre caixa estimada e caixa de referência, e OCR por taxa de correspondência exata da placa e erro por caractere. Separar imagens de ajuste de parâmetros e imagens de avaliação final; imagens semelhantes da mesma sequência não devem atravessar a divisão.

## 7. Falhas, limitações e riscos

- Só há uma montagem de recortes no pacote recebido; não há cenas completas para avaliar a localização da placa.
- Não há ground truth, logo não é possível declarar acurácia ou taxa de sucesso quantitativa.
- A limiarização global pode falhar com iluminação desigual, reflexos, desfoque e baixo contraste.
- CLAHE pode reforçar ruído; blur e abertura podem remover traços finos.
- Componentes conexos não equivalem automaticamente a caracteres: letras podem se tocar e um caractere pode se dividir em várias regiões.
- O limiar e a área mínima são parâmetros exploratórios, não valores otimizados.
- O dataset externo tem condições de acesso/licença que devem ser respeitadas.

## 8. Plano de conclusão para M3

| Tarefa | Responsável | Evidência esperada |
|---|---|---|
| Obter e organizar imagens autorizadas, documentando origem/licença | A definir pelo grupo | Lista de IDs, instruções de obtenção e descrição dos dados |
| Criar/revisar ground truth de caixas, texto e amostra de caracteres | A definir pelo grupo | CSV/JSON de anotações e protocolo de revisão |
| Implementar comparação de detecção por contornos e Haar Cascade | A definir pelo grupo | Caixas desenhadas, tabela de IoU/taxa de detecção e falhas |
| Implementar retificação da placa | A definir pelo grupo | Imagens antes/depois e validação visual |
| Refinar segmentação e avaliar contra referência | A definir pelo grupo | Máscaras/caixas e métricas quantitativas |
| Integrar OCR e medir desempenho | A definir pelo grupo | Transcrições previstas, texto esperado e taxa de erro |
| Atualizar relatório, README e vídeo | A definir pelo grupo | Relatório reproduzível e vídeo não listado de cerca de 10 minutos |

Os responsáveis devem ser definidos pelo grupo conforme a participação real. A conclusão não deve ser registrada como feita até que exista evidência no repositório.

## 9. Contribuições dos integrantes

O material recebido não contém evidências suficientes para atribuir contribuições individuais. O grupo deve preencher a tabela abaixo com tarefas reais e links/arquivos verificáveis.

| Integrante | Contribuição efetiva | Evidência |
|---|---|---|
| José Vitor da Rosa | A preencher pelo grupo | Arquivo, experimento, revisão ou registro |
| Kauã Kovalski de Campos | A preencher pelo grupo | Arquivo, experimento, revisão ou registro |
| Emanuel Muller Bueno | A preencher pelo grupo | Arquivo, experimento, revisão ou registro |

Commits são evidências auxiliares, mas não representam isoladamente toda a participação.

## 10. Uso de IA generativa

O pipeline e esta versão inicial da documentação foram preparados com assistência do ChatGPT (OpenAI), para estruturar o código experimental, executar uma comparação inicial e redigir o relatório. O grupo deve revisar as operações, reproduzir os resultados no ambiente de entrega e ajustar esta declaração para refletir todos os usos de IA ocorridos no projeto. O grupo é responsável por validar os resultados e o conteúdo submetido.

## Referências

- Laroca, R.; Cardoso, E. V.; Lucio, D. R.; Estevam, V.; Menotti, D. “On the Cross-dataset Generalization in License Plate Recognition.” VISAPP, 2022.
- RodoSol-ALPR: https://github.com/raysonlaroca/rodosol-alpr-dataset
- OpenCV — documentação oficial: https://docs.opencv.org/
- Tesseract OCR: https://github.com/tesseract-ocr/tesseract
